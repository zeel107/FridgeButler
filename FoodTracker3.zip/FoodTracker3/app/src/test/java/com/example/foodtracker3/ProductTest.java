package com.example.foodtracker3;

import org.junit.Test;

import static org.junit.Assert.*;

public class ProductTest {

    @Test
    public void getId() {
    }

    @Test
    public void setId() {
    }

    @Test
    public void getName() {
    }

    @Test
    public void setName() {
    }

    @Test
    public void getQuantity() {
    }

    @Test
    public void setQuantity() {
    }

    @Test
    public void getIdUnit() {
    }

    @Test
    public void setIdUnit() {
    }

    @Test
    public void getUnit() {
    }

    @Test
    public void setUnit() {
    }

    @Test
    public void getUnit_amount() {
    }
}