package com.example.foodtracker3;

import org.junit.Test;

import static org.junit.Assert.*;

public class DatabaseHelperTest {

    @Test
    public void getReadableDatabase() {
    }

    @Test
    public void onCreate() {
    }

    @Test
    public void onUpgrade() {
    }

    @Test
    public void addProduct() {
    }

    @Test
    public void removeProduct() {
    }

    @Test
    public void getAllProducts() {
    }

    @Test
    public void getUnit() {
    }

    @Test
    public void getUnits() {
    }

    @Test
    public void getCategory() {
    }

    @Test
    public void getCategories() {
    }

    @Test
    public void addTestProducts() {
    }
}