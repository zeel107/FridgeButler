package com.example.foodtracker3;

import org.junit.Test;

import static org.junit.Assert.*;

public class HomeFragmentTest {

    @Test
    public void onCreateView() {
    }

    @Test
    public void removeItem() {
    }

    @Test
    public void onCreateOptionsMenu() {
    }
}