package com.example.foodtracker3;
import org.junit.Test;
public class MainActivityTest {
    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    @org.junit.Test
    public void onCreate() {

    }
}