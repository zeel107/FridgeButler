package com.example.foodtracker3;

import org.junit.Test;

import static org.junit.Assert.*;

public class ExpJobServiceTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onStartJob() {
    }

    @Test
    public void onStopJob() {
    }

    @Test
    public void expDateChecker() {
    }

    @Test
    public void sendOnChannel1() {
    }

    @Test
    public void sendOnChannel2() {
    }
}