package com.example.foodtracker3;

import org.junit.Test;

import static org.junit.Assert.*;

public class AppNotifyTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void createNotificationChannels() {
    }
}